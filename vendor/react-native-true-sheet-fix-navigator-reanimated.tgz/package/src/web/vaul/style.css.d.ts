declare module './style.css';
