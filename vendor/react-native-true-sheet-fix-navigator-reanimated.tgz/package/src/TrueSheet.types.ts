import type { Component, ComponentType, ReactElement, ReactNode, RefObject } from 'react';
import type {
  ColorValue,
  HostInstance,
  NativeSyntheticEvent,
  StyleProp,
  ViewProps,
  ViewStyle,
} from 'react-native';

export interface DetentInfoEventPayload {
  /**
   * The index position from the provided `detents`.
   */
  index: number;
  /**
   * The Y position of the sheet relative to the screen.
   */
  position: number;
  /**
   * The detent value (0-1) for the current index.
   */
  detent: number;
}

export interface PositionChangeEventPayload extends DetentInfoEventPayload {
  /**
   * Indicates whether the position value is real-time (e.g., during drag or animation tracking).
   * When false, the position should be animated in JS.
   */
  realtime: boolean;
}

export type MountEvent = NativeSyntheticEvent<null>;
export type DetentChangeEvent = NativeSyntheticEvent<DetentInfoEventPayload>;
export type WillPresentEvent = NativeSyntheticEvent<DetentInfoEventPayload>;
export type DidPresentEvent = NativeSyntheticEvent<DetentInfoEventPayload>;
export type WillDismissEvent = NativeSyntheticEvent<null>;
export type DidDismissEvent = NativeSyntheticEvent<null>;
export type DismissAttemptEvent = NativeSyntheticEvent<null>;
export type DragBeginEvent = NativeSyntheticEvent<DetentInfoEventPayload>;
export type DragChangeEvent = NativeSyntheticEvent<DetentInfoEventPayload>;
export type DragEndEvent = NativeSyntheticEvent<DetentInfoEventPayload>;
export type PositionChangeEvent = NativeSyntheticEvent<PositionChangeEventPayload>;
export type DidFocusEvent = NativeSyntheticEvent<null>;
export type DidBlurEvent = NativeSyntheticEvent<null>;
export type WillFocusEvent = NativeSyntheticEvent<null>;
export type WillBlurEvent = NativeSyntheticEvent<null>;

/**
 * Options for customizing the grabber (drag handle) appearance.
 */
export interface GrabberOptions {
  /**
   * The width of the grabber pill.
   *
   * @default iOS: 36, Android: 32
   */
  width?: number;
  /**
   * The height of the grabber pill.
   *
   * @default iOS: 5, Android: 4
   */
  height?: number;
  /**
   * The top margin of the grabber from the sheet edge.
   *
   * @default iOS: 5, Android: 16
   */
  topMargin?: number;
  /**
   * The corner radius of the grabber pill.
   *
   * @default height / 2
   */
  cornerRadius?: number;
  /**
   * The color of the grabber.
   * Uses native vibrancy/material styling when not provided.
   */
  color?: ColorValue;
  /**
   * Whether the grabber color adapts to light/dark mode.
   * When enabled, the grabber uses vibrancy effect on iOS and
   * adjusts color based on the current theme on Android.
   *
   * @default true
   */
  adaptive?: boolean;
}

/**
 * Options for customizing (e.g. localizing) the accessibility strings
 * announced by screen readers.
 *
 * On iOS, the grabber strings only apply when `grabberOptions` is provided.
 * Without it, iOS uses the system grabber which is already localized.
 */
export interface AccessibilityOptions {
  /**
   * The accessibility label of the grabber.
   *
   * @default iOS: 'Sheet Grabber', Android: 'Drag handle'
   */
  grabberLabel?: string;
  /**
   * The accessibility hint of the grabber.
   *
   * @platform ios
   * @default 'Double-tap to expand. Swipe up or down to resize the sheet'
   */
  grabberHint?: string;
  /**
   * The value announced when the sheet is at the last detent.
   *
   * @default 'Expanded'
   */
  expandedValue?: string;
  /**
   * The value announced when the sheet is at the first detent.
   *
   * @default 'Collapsed'
   */
  collapsedValue?: string;
  /**
   * The value announced when the sheet is at an intermediate detent.
   * Supports `{index}` and `{count}` placeholders.
   *
   * @default 'Detent {index} of {count}'
   */
  detentValue?: string;
  /**
   * The label of the expand accessibility action.
   *
   * @platform android
   * @default 'Expand'
   */
  expandActionLabel?: string;
  /**
   * The label of the collapse accessibility action.
   *
   * @platform android
   * @default 'Collapse'
   */
  collapseActionLabel?: string;
  /**
   * The title announced when the sheet appears.
   * Sets the accessibility pane title on Android and the
   * hidden dialog title on Web.
   *
   * @platform android, web
   * @default Android: 'Bottom sheet', Web: 'Sheet'
   */
  paneTitle?: string;
}

/**
 * Scroll edge effect style for iOS 26+.
 * Controls the blur/gradient overlay applied to scroll view edges.
 *
 * @platform ios 26+
 */
export type ScrollEdgeEffect = 'automatic' | 'hard' | 'soft' | 'hidden';

/**
 * What the sheet insets the bottom of a plugged scrollable's content for.
 * See `ScrollableOptions.contentInsetAdjustment`.
 */
export type ContentInsetAdjustment = 'automatic' | 'safe-area' | 'footer' | 'never';

/**
 * Options for scrollable behavior.
 */
export interface ScrollableOptions {
  /**
   * What the sheet insets the bottom of the scroll content for, so the last
   * item clears whatever covers the scroll view's bottom edge.
   *
   * - `'automatic'`: The bottom safe-area inset while the content can scroll
   *   (home indicator on iOS, navigation bar on Android), plus the height of
   *   an `absolute` footer floating over the scroll view. The footer then
   *   counts toward the `auto` detent so the content ends above it.
   * - `'safe-area'`: The safe-area inset only — content scrolls under an
   *   absolute footer.
   * - `'footer'`: The absolute footer only — you pad for the safe area.
   * - `'never'`: No inset — you pad the content yourself.
   *
   * The safe-area inset only applies while the sheet's `insetAdjustment` is
   * `'automatic'`; a relative footer absorbs it instead. The footer inset is
   * independent of `insetAdjustment` — it only covers the part of the footer
   * overlapping the scroll view, and stacks with the keyboard inset while the
   * footer rises above the keyboard.
   *
   * On iOS, the safe-area inset sets the scroll view's native
   * [`contentInsetAdjustmentBehavior`](https://developer.apple.com/documentation/uikit/uiscrollview/contentinsetadjustmentbehavior)
   * to `automatic` while it's plugged into the sheet; Android and Web apply
   * the inset themselves.
   *
   * @default 'automatic'
   */
  contentInsetAdjustment?: ContentInsetAdjustment;

  /**
   * Extra offset when scrolling to the focused input when keyboard appears.
   *
   * @default 0
   */
  keyboardScrollOffset?: number;

  /**
   * Adjusts the bottom inset applied to the scrollable when the keyboard is shown.
   * Positive values increase the inset; negative values reduce it.
   * Pass `-insets.bottom` to cancel out safe-area padding already included in
   * the content's `paddingBottom`.
   * Does not affect the auto scroll of the focused input — it always targets
   * the keyboard edge.
   *
   * @default 0
   */
  keyboardOffset?: number;

  /**
   * Whether scrolling the content expands the sheet to the next detent.
   * When `false`, only the grabber can expand the sheet.
   *
   * @default true
   */
  scrollingExpandsSheet?: boolean;

  /**
   * The scroll edge effect applied to the top edge of the scroll view.
   *
   * @platform ios 26+
   * @default 'hidden'
   */
  topScrollEdgeEffect?: ScrollEdgeEffect;

  /**
   * The scroll edge effect applied to the bottom edge of the scroll view.
   *
   * @platform ios 26+
   * @default 'hidden'
   */
  bottomScrollEdgeEffect?: ScrollEdgeEffect;
}

/**
 * Options for header behavior
 */
export interface HeaderOptions {
  /**
   * How the header participates in the sheet layout.
   *
   * - `'relative'`: The header takes up space above the content, and its height
   *   is included in the `auto` detent calculation.
   * - `'absolute'`: The header floats over the content, pinned to the top edge,
   *   and is excluded from the `auto` detent calculation.
   *
   * @default 'relative'
   */
  position?: 'relative' | 'absolute';
}

/**
 * Options for foldables. Applies while the device is half-open with a horizontal
 * fold (tabletop). In book posture (vertical fold), iOS already keeps sheets on
 * one panel — use `placement` to pick the side.
 */
export interface FoldOptions {
  /**
   * The detent that rests on the hinge in tabletop, so the sheet fills the panel
   * below it. In any other posture the detent keeps its own value. Lower detents
   * stay below it and higher ones above it, so the detents keep their order.
   */
  hingeDetentIndex?: number;

  /**
   * How the sheet treats the hinge in tabletop.
   *
   * - `'none'`: Detents are free to cross the hinge.
   * - `'avoid'`: Caps every detent at the hinge, so the sheet never crosses it.
   * - `'snap'`: Like `'avoid'`, and also moves the sheet to `hingeDetentIndex` when
   *    the device enters tabletop, then back to its previous detent when it leaves,
   *    unless the sheet was moved off the hinge in between.
   *
   * @default 'none'
   */
  hingeBehavior?: 'none' | 'avoid' | 'snap';
}

/**
 * Options for footer behavior
 */
export interface FooterOptions {
  /**
   * How the footer participates in the sheet layout.
   *
   * - `'relative'`: The footer takes up space below the content, pinned to the
   *   bottom edge. Its height is included in the `auto` detent calculation but
   *   excluded from the `peek` detent (it's pushed off-screen at peek).
   * - `'absolute'`: The footer floats over the content, pinned to the bottom
   *   edge. Its height is excluded from the `auto` detent calculation but
   *   included in the `peek` detent.
   *
   * @default 'relative'
   */
  position?: 'relative' | 'absolute';

  /**
   * Adjusts how far an `absolute` footer rises when the keyboard opens.
   * Positive values raise it higher; negative values reduce the rise.
   * Pass `-insets.bottom` to tuck the footer's safe-area padding behind the keyboard.
   * A `relative` footer stays in the layout flow behind the keyboard, so this has no effect.
   *
   * @default 0
   */
  keyboardOffset?: number;

  /**
   * Whether an `absolute` footer rises above the keyboard when it opens.
   * Set to `false` to keep the footer pinned to the sheet's bottom edge behind the keyboard.
   * With footer inset adjustment enabled, any uncovered portion still adds scroll padding
   * and contributes to the expanded `auto` height.
   * The pinned footer keeps its safe-area padding and ignores `keyboardOffset`.
   * A `relative` footer never rises, so this has no effect.
   *
   * @platform ios, android
   * @default true
   */
  avoidKeyboard?: boolean;
}

/**
 * Inset adjustment behavior for the sheet content.
 */
export type InsetAdjustment =
  /**
   * Automatically adjusts the sheet height to account for system insets (safe area).
   * This ensures the sheet content is properly inset from system UI elements.
   */
  | 'automatic'
  /**
   * Does not adjust the sheet height for system insets.
   * The sheet height is calculated purely from the detent values.
   */
  | 'never';

/**
 * How far the sheet must be swiped down from its lowest detent to dismiss.
 */
export type DismissThreshold =
  /**
   * Past half of the lowest detent, or a quick flick. Matches iOS.
   */
  | 'half'
  /**
   * A short drag (56 dp) or any downward fling (125 dp/s),
   * like Compose Material3's `ModalBottomSheet`.
   */
  | 'short';

/**
 * Blur style mapped to native values in IOS.
 *
 * @platform ios
 */
export type BackgroundBlur =
  | 'light'
  | 'dark'
  | 'default'
  | 'extra-light'
  | 'regular'
  | 'prominent'
  | 'system-ultra-thin-material'
  | 'system-thin-material'
  | 'system-material'
  | 'system-thick-material'
  | 'system-chrome-material'
  | 'system-ultra-thin-material-light'
  | 'system-thin-material-light'
  | 'system-material-light'
  | 'system-thick-material-light'
  | 'system-chrome-material-light'
  | 'system-ultra-thin-material-dark'
  | 'system-thin-material-dark'
  | 'system-material-dark'
  | 'system-thick-material-dark'
  | 'system-chrome-material-dark';

export type DetentBackground =
  | string
  | { color: ColorValue; blur?: never }
  | { blur: BackgroundBlur; color?: never };

/**
 * Supported Sheet detent.
 */
export type SheetDetent =
  /**
   * Auto resize based on content height, clamped to container height.
   * Use the `maxContentHeight` prop to set a custom limit.
   *
   * @platform android
   * @platform ios 16+
   */
  | 'auto'

  /**
   * Collapsed height based on the combined `header` and `footer` heights.
   * Render a `TrueSheetPeek` component within the content to also include
   * the content up to its bottom edge.
   * Falls back to a fixed height of `150` when none is provided.
   *
   * @platform android
   * @platform ios 16+
   */
  | 'peek'

  /**
   * Relative height as a fraction (0-1) of the available height.
   * For example, 0.5 represents 50% of the available height.
   *
   * @platform android
   * @platform ios 16+
   */
  | number;

export interface TrueSheetProps extends ViewProps {
  /**
   * The name to reference this sheet. It has to be unique.
   * You can then present this sheet globally using its `name`.
   *
   * Example:
   * ```ts
   * <TrueSheet name="my-awesome-sheet">
   *   <MyComponent />
   * </TrueSheet>
   * ```
   * ```ts
   * TrueSheet.present('my-awesome-sheet')
   * ```
   */
  name?: string;
  /**
   * The detents you want the Sheet to support.
   * Maximum of 3 detents only; collapsed, half-expanded, expanded.
   *
   * Example:
   * ```ts
   * detents={['auto', 0.6, 1]}
   * ```
   *
   * @note It's recommended to sort detents from smallest to largest.
   * When using `auto`, place it at the first index if you plan to adjust content dynamically.
   *
   * @default [0.5, 1]
   */
  detents?: SheetDetent[];

  /**
   * Specify whether the sheet background is dimmed.
   * Set to `false` to allow interaction with the background components.
   *
   * @default true
   */
  dimmed?: boolean;

  /**
   * The color of the dim overlay behind the sheet.
   * This is ignored if `dimmed` is set to `false`.
   *
   * @default '#000000'
   */
  dimColor?: ColorValue;

  /**
   * The maximum opacity of the dim overlay behind the sheet (0 to 1).
   * This is ignored if `dimmed` is set to `false`.
   *
   * @default 0.5
   */
  dimOpacity?: number;

  /**
   * Initially present the sheet, after mounting, at a given detent index.
   *
   * @note This property is only used during the initial mount.
   * @default -1
   */
  initialDetentIndex?: number;

  /**
   * Specify whether the sheet should animate after mounting.
   * Used with `initialDetentIndex`.
   *
   * @default true
   */
  initialDetentAnimated?: boolean;

  /**
   * Specify whether the sheet content should mount lazily, on first presentation.
   * Set to `false` to mount the content before presentation without presenting the sheet.
   * Use this when content is not ready on the first render, then call `present()`
   * after your readiness signal so auto detents measure the settled content.
   *
   * Content that requires window attachment to measure, such as SwiftUI-hosted views,
   * still only measures during presentation.
   *
   * @platform android
   * @platform ios
   * @default true
   */
  lazy?: boolean;

  /**
   * The detent index that the sheet should start to dim the background.
   * This is ignored if `dimmed` is set to `false`.
   *
   * @default 0
   */
  dimmedDetentIndex?: number;

  /**
   * Prevents interactive dismissal of the Sheet.
   * Blocked attempts fire `onDismissAttempt`, so you can confirm before dismissing programmatically.
   *
   * @default true
   */
  dismissible?: boolean;

  /**
   * How far the sheet must be swiped down from its lowest detent to dismiss.
   * Set to `'short'` to dismiss on a short drag or fling, like Compose Material3's sheet.
   *
   * @platform android
   * @platform web
   * @default 'half'
   */
  dismissThreshold?: DismissThreshold;

  /**
   * Enables or disables dragging the sheet to resize it.
   * When disabled, the sheet becomes static and can only be resized programmatically.
   *
   * @default true
   */
  draggable?: boolean;

  /**
   * Main sheet background color.
   * Uses system default when not provided.
   *
   * On supported iOS 26.1+ devices, uses a native color effect.
   * `backgroundBlur` takes precedence on iOS.
   * Use `backgroundStyle.backgroundColor` for an exact color or to tint glass or blur.
   */
  backgroundColor?: ColorValue;

  /**
   * Backgrounds matched to `detents` by index. Strings are color values.
   * Null or missing entries inherit
   * `backgroundColor`/`backgroundBlur`. iOS 26.1+ transitions natively.
   * Other platforms cross-fade after passing the midpoint between detents.
   * Blur entries use the sheet background on Android and Web.
   */
  detentBackgrounds?: (DetentBackground | null)[];

  /**
   * Custom background rendered behind the header, content, and footer.
   * The wrapper fills the sheet and ignores touches.
   * Size the element to fill it with `StyleSheet.absoluteFill`.
   */
  background?: ReactNode;

  /**
   * Style for the background wrapper. Only `backgroundColor` is supported.
   * Use an opaque color for an exact color, or a translucent color to tint glass or blur.
   */
  backgroundStyle?: StyleProp<Pick<ViewStyle, 'backgroundColor'>>;

  /**
   * The sheet corner radius.
   *
   * - `undefined` (not provided): Uses system default corner radius
   * - `0`: Sharp corners (no rounding)
   * - `> 0`: Custom corner radius value
   */
  cornerRadius?: number;

  /**
   * Shows a native grabber (or drag handle) on the sheet.
   *
   * iOS uses the native `UISheetPresentationController` grabber.
   * Android renders a native view following Material Design 3 specifications.
   *
   * @default true
   */
  grabber?: boolean;

  /**
   * Options for customizing the grabber appearance.
   * Only applies when `grabber` is `true`.
   */
  grabberOptions?: GrabberOptions;

  /**
   * Options for customizing (e.g. localizing) the accessibility strings
   * announced by screen readers.
   */
  accessibilityOptions?: AccessibilityOptions;

  /**
   * Controls the sheet presentation style on iPad and web (landscape/tablet).
   * - `'page'`: bottom-attached page sheet (full or readable width).
   * - `'form'`: centered floating form sheet (default form-sheet width).
   *
   * `'form'` is absolute — `maxContentWidth` is ignored when set.
   *
   * @platform ios 17+, web
   * @default 'page'
   */
  presentation?: 'page' | 'form';

  /**
   * The blur effect style on iOS.
   * Takes precedence over `backgroundColor`.
   * Use `backgroundStyle.backgroundColor` to tint the blur.
   *
   * @platform ios
   */
  backgroundBlur?: BackgroundBlur;

  /**
   * Overrides `large` or `100%` height.
   * Also sets the maximum height for 'auto' detents.
   */
  maxContentHeight?: number;

  /**
   * The maximum width of the sheet content.
   * On Android and Web, defaults to `640dp`. On iOS, the sheet uses system default width.
   *
   * Ignored on phones in portrait orientation.
   */
  maxContentWidth?: number;

  /**
   * Horizontal placement of the sheet within the screen.
   *
   * - `'automatic'`: The system decides (default). Centered on Android, Web, and iOS 26 and below.
   * - `'center'`: Centers the sheet horizontally.
   * - `'leading'`: Places the sheet on the leading edge (left in LTR, right in RTL).
   * - `'trailing'`: Places the sheet on the trailing edge (right in LTR, left in RTL).
   *
   * `'automatic'` and `'center'` only differ on iOS 27+, where they map to
   * `UISheetPresentationController.preferredPlacement`.
   *
   * Ignored on phones in portrait orientation.
   *
   * @default 'automatic'
   */
  placement?: 'automatic' | 'leading' | 'center' | 'trailing';

  /**
   * The offset from the screen edge.
   * Only applies when `placement` is `'leading'` or `'trailing'`.
   *
   * @platform android
   * @platform web
   * @default 16
   */
  placementOffset?: number;

  /**
   * How the sheet behaves on a foldable.
   *
   * @platform ios 27.1+
   */
  foldOptions?: FoldOptions;

  /**
   * Controls how the sheet adjusts its height for system insets (safe area).
   *
   * - `'automatic'`: Adds the bottom safe area inset to the sheet height,
   *    ensuring content is properly inset from system UI elements.
   * - `'never'`: Does not adjust for insets; height is calculated purely from detent values.
   *
   * @default 'automatic'
   */
  insetAdjustment?: InsetAdjustment;

  /**
   * The elevation (shadow depth) of the sheet.
   *
   * @platform android
   * @platform web
   * @default 4
   */
  elevation?: number;

  /**
   * A component that is fixed at the top of the Sheet content.
   * Useful for search bars, titles, or other header content.
   */
  header?: ComponentType<unknown> | ReactElement;

  /**
   * Style for the header container.
   */
  headerStyle?: StyleProp<ViewStyle>;

  /**
   * Options for header behavior.
   */
  headerOptions?: HeaderOptions;

  /**
   * A component that floats at the bottom of the Sheet.
   */
  footer?: ComponentType<unknown> | ReactElement;

  /**
   * Style for the footer container.
   */
  footerStyle?: StyleProp<ViewStyle>;

  /**
   * A ref to the scrollable component (e.g. `ScrollView`, `FlatList`)
   * rendered within the sheet content. Lists that expose an imperative handle
   * (e.g. `LegendList`, `FlashList`) work too, through their
   * `getScrollableNode()` or `getNativeScrollRef()`.
   * Required for scrollable handling — nested scrolling, keyboard insets,
   * and `auto` detent sizing are wired to this scrollable.
   *
   * Example:
   * ```tsx
   * const scrollableRef = useRef<ScrollView>(null)
   *
   * <TrueSheet scrollableRef={scrollableRef}>
   *   <ScrollView ref={scrollableRef} />
   * </TrueSheet>
   * ```
   */
  scrollableRef?: RefObject<
    | Component<unknown>
    | HostInstance
    | { getScrollableNode(): unknown }
    | { getNativeScrollRef(): unknown }
    | null
  >;

  /**
   * Options for scrollable behavior.
   * Applies to the scrollable provided via `scrollableRef`.
   */
  scrollableOptions?: ScrollableOptions;

  /**
   * Options for footer behavior.
   */
  footerOptions?: FooterOptions;

  /**
   * Renders the sheet as a detached floating card, not attached to the bottom edge.
   *
   * @platform web
   * @default false
   */
  detached?: boolean;

  /**
   * The offset from the bottom edge when [`detached`](#detached) is enabled.
   *
   * @platform web
   * @default 16
   */
  detachedOffset?: number;

  /**
   * Called when the sheet's content is mounted and ready.
   * The sheet automatically waits for this event before presenting.
   */
  onMount?: (event: MountEvent) => void;

  /**
   * Called when the Sheet is about to be presented.
   */
  onWillPresent?: (event: WillPresentEvent) => void;

  /**
   * Called when the Sheet has been presented.
   * Comes with the detent info.
   */
  onDidPresent?: (event: DidPresentEvent) => void;

  /**
   * Called when the Sheet is about to be dismissed
   */
  onWillDismiss?: (event: WillDismissEvent) => void;

  /**
   * Called when the Sheet has been dismissed
   */
  onDidDismiss?: (event: DidDismissEvent) => void;

  /**
   * Called when the user tries to dismiss the sheet while `dismissible` is `false`,
   * e.g. by dragging down or pressing back/escape. Tapping the dim does not count.
   * The sheet stays presented. Confirm with the user, then call `dismiss()` to proceed.
   */
  onDismissAttempt?: (event: DismissAttemptEvent) => void;

  /**
   * Called when the detent of the sheet has changed.
   * Either by dragging or programatically.
   */
  onDetentChange?: (event: DetentChangeEvent) => void;

  /**
   * Called when the sheet has began dragging.
   * Comes with the detent info.
   */
  onDragBegin?: (event: DragBeginEvent) => void;

  /**
   * Called when the sheet is being dragged.
   * Comes with the detent info.
   */
  onDragChange?: (event: DragChangeEvent) => void;

  /**
   * Called when the sheet dragging has ended.
   * Comes with the detent info.
   */
  onDragEnd?: (event: DragEndEvent) => void;

  /**
   * Called when the sheet's position changes.
   * This fires continuously during sheet position changes.
   * Comes with the detent info.
   */
  onPositionChange?: (event: PositionChangeEvent) => void;

  /**
   * Called when the sheet is about to regain focus because a sheet presented on top of it is being dismissed.
   */
  onWillFocus?: (event: WillFocusEvent) => void;

  /**
   * Called when the sheet regains focus after a sheet presented on top of it is dismissed.
   */
  onDidFocus?: (event: DidFocusEvent) => void;

  /**
   * Called when the sheet is about to lose focus because another sheet is being presented on top of it.
   */
  onWillBlur?: (event: WillBlurEvent) => void;

  /**
   * Called when the sheet loses focus because another sheet is presented on top of it.
   */
  onDidBlur?: (event: DidBlurEvent) => void;

  /**
   * Called when the hardware back button is pressed on Android.
   * Optionally return `false` to let the back event propagate to other handlers (e.g. navigation).
   *
   * @platform android
   */
  onBackPress?: () => boolean | void;
}

/**
 * Imperative methods available on a TrueSheet ref.
 *
 * Example:
 * ```tsx
 * const sheetRef = useRef<TrueSheetMethods>(null);
 * sheetRef.current?.present();
 * ```
 */
export interface TrueSheetMethods {
  /**
   * Present the sheet at a given detent index.
   *
   * @param index - The detent index to present at (default: `0`).
   * @param animated - Whether to animate the presentation (default: `true`). Ignored on web.
   */
  present(index?: number, animated?: boolean): Promise<void>;

  /**
   * Resize the sheet to a given detent index.
   *
   * @param index - The detent index to resize to.
   */
  resize(index: number): Promise<void>;

  /**
   * Dismiss this sheet and all sheets presented on top of it in a single animation.
   *
   * @param animated - Whether to animate the dismissal (default: `true`). Ignored on web.
   */
  dismiss(animated?: boolean): Promise<void>;

  /**
   * Dismiss only the sheets presented on top of this sheet, keeping this sheet presented.
   * No-op if no sheets are presented on top.
   *
   * @param animated - Whether to animate the dismissal (default: `true`). Ignored on web.
   */
  dismissStack(animated?: boolean): Promise<void>;
}

/**
 * Static methods exposed on the `TrueSheet` component for controlling sheets by `name`.
 *
 * Example:
 * ```ts
 * TrueSheet.present('my-sheet')
 * ```
 *
 * @note Not supported on web — use the `useTrueSheet()` hook instead.
 */
export interface TrueSheetStaticMethods {
  /**
   * Present the sheet with the given `name`.
   *
   * @throws if no sheet with the given `name` is registered.
   */
  present(name: string, index?: number, animated?: boolean): Promise<void>;

  /**
   * Resize the sheet with the given `name`.
   *
   * @throws if no sheet with the given `name` is registered.
   */
  resize(name: string, index: number): Promise<void>;

  /**
   * Dismiss the sheet with the given `name` and all sheets presented on top of it.
   *
   * @throws if no sheet with the given `name` is registered.
   */
  dismiss(name: string, animated?: boolean): Promise<void>;

  /**
   * Dismiss only the sheets presented on top of the sheet with the given `name`.
   *
   * @throws if no sheet with the given `name` is registered.
   */
  dismissStack(name: string, animated?: boolean): Promise<void>;

  /**
   * Dismiss every presented sheet, from the top of the stack downward.
   */
  dismissAll(animated?: boolean): Promise<void>;
}
