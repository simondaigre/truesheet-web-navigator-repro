import * as ExpoRouter from 'expo-router';
import type { ParamListBase } from './base-types';
import type { TrueSheetNavigationOptions, TrueSheetNavigationProp, TrueSheetNavigationState, TrueSheetNavigatorProps, TrueSheetStandardEventMap } from './types';
declare const SheetNavigator: import("react").ForwardRefExoticComponent<Omit<import("expo-router/build/standard-navigation/types").StandardRouterNavigatorProps<TrueSheetNavigationState<ParamListBase>, TrueSheetNavigationOptions, TrueSheetStandardEventMap, object, ExpoRouter.StackRouterOptions>, "children"> & Partial<Pick<import("expo-router/build/standard-navigation/types").StandardRouterNavigatorProps<TrueSheetNavigationState<ParamListBase>, TrueSheetNavigationOptions, TrueSheetStandardEventMap, object, ExpoRouter.StackRouterOptions>, "children">> & import("react").RefAttributes<unknown> & {
    unstable_screenErrorBoundary?: import("react").ComponentType<import("expo-router").ErrorBoundaryProps>;
}> & {
    Screen: (props: ExpoRouter.ScreenProps<TrueSheetNavigationOptions, TrueSheetNavigationState<ParamListBase>, TrueSheetStandardEventMap & import("expo-router/react-navigation").EventMapBase>) => null;
    Protected: typeof import("expo-router/build/views/Protected").Protected;
};
type SheetProps = Omit<React.ComponentProps<typeof SheetNavigator>, 'screenListeners'> & Pick<TrueSheetNavigatorProps, 'screenListeners'>;
/**
 * TrueSheet navigator layout for Expo Router.
 *
 * @example
 * ```tsx
 * // app/sheet/_layout.tsx
 * import { Sheet } from '@lodev09/react-native-true-sheet/navigation/expo-router';
 *
 * export default function SheetLayout() {
 *   return (
 *     <Sheet initialRouteName="(home)">
 *       <Sheet.Screen name="details" options={{ detents: [0.5, 1] }} />
 *     </Sheet>
 *   );
 * }
 * ```
 */
export declare const Sheet: React.ComponentType<SheetProps> & {
    Screen: typeof SheetNavigator.Screen;
    Protected: typeof SheetNavigator.Protected;
};
/**
 * Hook to access TrueSheet navigation with the resize helper.
 * Built on expo-router's `useNavigation`.
 */
export declare const useTrueSheetNavigation: <T extends ParamListBase = ParamListBase>() => TrueSheetNavigationProp<T>;
export { TrueSheetActions, type TrueSheetActionType } from '../actions';
export type { DetentInfoEventPayload, PositionChangeEventPayload } from '../../TrueSheet.types';
export type { TrueSheetNavigationEventMap, TrueSheetNavigationHelpers, TrueSheetNavigationOptions, TrueSheetNavigationProp, TrueSheetNavigationState, TrueSheetScreenProps, } from './types';
//# sourceMappingURL=index.d.ts.map