import { type TrueSheetActionType } from '../actions';
import type { StackRouterFactory, TrueSheetRouterFactory, TrueSheetRouterState } from './types';
type ActionResult = {
    state: TrueSheetRouterState;
    affectedRouteKey?: string;
};
/**
 * `RouterActionHandling.Unhandled` from Expo Router 58+, which deprecates `null`.
 */
export type Unhandled = 'UNHANDLED';
type RouterExtension = (context: {
    baseRouter: {
        getStateForAction(state: TrueSheetRouterState, action: TrueSheetActionType, options: object): ActionResult | Unhandled;
    };
    options: {
        initialRouteName?: string;
    };
}) => object;
/**
 * `extendRouter` from Expo Router 58+. Declared locally because the
 * Expo Router types this package builds against predate it.
 */
export type ExtendRouter = (base: StackRouterFactory, extension: RouterExtension, options: {
    type: string;
}) => TrueSheetRouterFactory;
/**
 * Router for Expo Router 58+, where navigator state is seeded by Expo Router
 * (no `getInitialState`/`getRehydratedState`) and `getStateForAction` returns
 * `{ state, affectedRouteKey }`.
 */
export declare const extendTrueSheetRouter: (extendRouter: ExtendRouter, stackRouter: StackRouterFactory, unhandled: Unhandled) => TrueSheetRouterFactory;
export {};
//# sourceMappingURL=extendTrueSheetRouter.d.ts.map