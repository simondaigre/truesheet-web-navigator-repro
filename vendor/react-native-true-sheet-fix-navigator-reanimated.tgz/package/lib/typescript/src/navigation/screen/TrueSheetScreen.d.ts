import type { TrueSheetScreenProps } from './types';
export declare const TrueSheetScreen: ({ detentIndex, resizeKey, dispatch, emit, routeKey, closing, detents, children, positionChangeHandler, ...sheetProps }: TrueSheetScreenProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TrueSheetScreen.d.ts.map