import type { ComponentType } from 'react';
import type { TrueSheetScreenProps } from './types';
export declare const registerReanimatedScreen: (screen: ComponentType<TrueSheetScreenProps>) => void;
export declare const getReanimatedScreen: () => ComponentType<TrueSheetScreenProps> | null;
//# sourceMappingURL=reanimatedScreen.d.ts.map