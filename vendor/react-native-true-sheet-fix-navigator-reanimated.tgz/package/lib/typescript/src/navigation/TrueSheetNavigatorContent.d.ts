import type { NavigatorArgs } from 'standard-navigation';
import type { TrueSheetNavigationOptions, TrueSheetNavigatorContentExtraProps, TrueSheetStandardEventMap } from './types';
export type TrueSheetNavigatorContentProps = NavigatorArgs<TrueSheetNavigationOptions, TrueSheetStandardEventMap> & TrueSheetNavigatorContentExtraProps;
export declare const TrueSheetNavigatorContent: ({ routes, dispatch, descriptors, emitter, }: TrueSheetNavigatorContentProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=TrueSheetNavigatorContent.d.ts.map