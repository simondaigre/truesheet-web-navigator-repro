import type { NavigatorArgs } from 'standard-navigation';
import type { DetentInfoEventPayload, PositionChangeEventPayload, TrueSheetProps } from '../TrueSheet.types';
import type { TrueSheetActionType } from './actions';
import type { DefaultNavigatorOptions, Descriptor, NavigationAction, NavigationHelpers, NavigationProp, NavigationState, ParamListBase, RouteProp, Router, StackActionHelpers, StackRouterOptions } from './base-types';
export type PositionChangeHandler = (payload: PositionChangeEventPayload) => void;
export type TrueSheetNavigationEventMap = {
    /**
     * Event fired when the sheet is about to be presented.
     */
    sheetWillPresent: {
        data: DetentInfoEventPayload;
    };
    /**
     * Event fired when the sheet has been presented.
     */
    sheetDidPresent: {
        data: DetentInfoEventPayload;
    };
    /**
     * Event fired when the sheet is about to be dismissed.
     */
    sheetWillDismiss: {
        data: undefined;
    };
    /**
     * Event fired when the sheet has been dismissed.
     */
    sheetDidDismiss: {
        data: undefined;
    };
    /**
     * Event fired when the user tries to dismiss a non-dismissible sheet.
     */
    sheetDismissAttempt: {
        data: undefined;
    };
    /**
     * Event fired when the sheet's detent changes.
     */
    sheetDetentChange: {
        data: DetentInfoEventPayload;
    };
    /**
     * Event fired when the user starts dragging the sheet.
     */
    sheetDragBegin: {
        data: DetentInfoEventPayload;
    };
    /**
     * Event fired while the user is dragging the sheet.
     */
    sheetDragChange: {
        data: DetentInfoEventPayload;
    };
    /**
     * Event fired when the user stops dragging the sheet.
     */
    sheetDragEnd: {
        data: DetentInfoEventPayload;
    };
    /**
     * Event fired when the sheet's position changes.
     */
    sheetPositionChange: {
        data: PositionChangeEventPayload;
    };
    /**
     * Event fired when the sheet is about to regain focus.
     */
    sheetWillFocus: {
        data: undefined;
    };
    /**
     * Event fired when the sheet regains focus.
     */
    sheetDidFocus: {
        data: undefined;
    };
    /**
     * Event fired when the sheet is about to lose focus.
     */
    sheetWillBlur: {
        data: undefined;
    };
    /**
     * Event fired when the sheet loses focus.
     */
    sheetDidBlur: {
        data: undefined;
    };
};
/**
 * A navigation state tagged as `true-sheet`, with the sheet fields the router
 * adds to each route.
 * Generic over the base state so each entry point can bind its own
 * `NavigationState` — see `./base-types`.
 */
export type TrueSheetStateOf<State extends {
    routes: readonly unknown[];
}> = Omit<State, 'routes'> & {
    type: 'true-sheet';
    routes: (State['routes'][number] & {
        resizeIndex?: number;
        resizeKey?: number;
        closing?: boolean;
        dismissing?: boolean;
    })[];
};
export type TrueSheetNavigationState<ParamList extends ParamListBase> = TrueSheetStateOf<NavigationState<ParamList>>;
export type TrueSheetRouterState = TrueSheetNavigationState<ParamListBase>;
export type TrueSheetRouterOptions = StackRouterOptions;
export type TrueSheetRouter = Router<TrueSheetRouterState, TrueSheetActionType>;
/**
 * The wrapped router factory — also the shape `createTrueSheetRouter` accepts,
 * pre-instantiated so either entry point's `StackRouterFactory` fits it.
 */
export type TrueSheetRouterFactory = (options: TrueSheetRouterOptions) => TrueSheetRouter;
/**
 * The base `StackRouter` factory to wrap, typed generically over the state and
 * action types the wrapper threads through — `StackRouter` is structural and
 * never touches the sheet-specific fields.
 * Injected by each entry point so the shared router never imports
 * `@react-navigation/*` at runtime (Expo Router apps don't install it).
 */
export type StackRouterFactory = <State extends NavigationState<ParamListBase>, Action extends NavigationAction>(options: TrueSheetRouterOptions) => Router<State, Action>;
/**
 * `TrueSheetNavigationEventMap` in the `standard-navigation` event-map shape.
 */
export type TrueSheetStandardEventMap = {
    [K in keyof TrueSheetNavigationEventMap]: {
        data: TrueSheetNavigationEventMap[K]['data'];
        canPreventDefault: false;
    };
};
export type TrueSheetRoute = TrueSheetNavigationState<ParamListBase>['routes'][number];
export type TrueSheetDispatch = (action: TrueSheetActionType) => void;
export type TrueSheetEmitFn = NavigatorArgs<TrueSheetNavigationOptions, TrueSheetStandardEventMap>['emitter']['emit'];
/**
 * Props injected into the navigator content by each adapter
 * (React Navigation's `mapper` / Expo Router's `createProps`).
 * Raw routes carry the custom fields (`closing`, `dismissing`, `resizeIndex`, `resizeKey`)
 * that the standard state strips out.
 */
export interface TrueSheetNavigatorContentExtraProps {
    routes: TrueSheetRoute[];
    dispatch: TrueSheetDispatch;
}
/**
 * Generic over the base helpers so each entry point can bind its own
 * `StackActionHelpers` — see `./base-types`.
 */
export type TrueSheetActionHelpersOf<Helpers> = Helpers & {
    /**
     * Resize the sheet to a specific detent index.
     */
    resize(index?: number): void;
};
export type TrueSheetActionHelpers<ParamList extends ParamListBase> = TrueSheetActionHelpersOf<StackActionHelpers<ParamList>>;
export type TrueSheetNavigationProp<ParamList extends ParamListBase, RouteName extends keyof ParamList = string, NavigatorID extends string | undefined = undefined> = NavigationProp<ParamList, RouteName, NavigatorID, TrueSheetNavigationState<ParamList>, TrueSheetNavigationOptions, TrueSheetNavigationEventMap> & TrueSheetActionHelpers<ParamList>;
export type TrueSheetScreenProps<ParamList extends ParamListBase, RouteName extends keyof ParamList = string, NavigatorID extends string | undefined = undefined> = {
    navigation: TrueSheetNavigationProp<ParamList, RouteName, NavigatorID>;
    route: RouteProp<ParamList, RouteName>;
};
export type TrueSheetNavigationHelpers = NavigationHelpers<ParamListBase, TrueSheetNavigationEventMap>;
export type TrueSheetNavigationSheetProps = Pick<TrueSheetProps, 'detents' | 'backgroundColor' | 'detentBackgrounds' | 'background' | 'backgroundStyle' | 'cornerRadius' | 'dismissible' | 'draggable' | 'grabber' | 'grabberOptions' | 'accessibilityOptions' | 'dimmed' | 'dimColor' | 'dimOpacity' | 'dimmedDetentIndex' | 'backgroundBlur' | 'maxContentHeight' | 'maxContentWidth' | 'presentation' | 'style' | 'header' | 'headerStyle' | 'headerOptions' | 'footer' | 'footerStyle' | 'footerOptions' | 'scrollableRef' | 'scrollableOptions' | 'insetAdjustment' | 'placement' | 'placementOffset' | 'foldOptions' | 'elevation' | 'detached' | 'detachedOffset'>;
/**
 * Screen options for TrueSheet navigator screens.
 */
export type TrueSheetNavigationOptions = TrueSheetNavigationSheetProps & {
    /**
     * The detent index to present at.
     * @default 0
     */
    detentIndex?: number;
    /**
     * Use ReanimatedTrueSheet for this screen.
     * Enables worklet-based `onPositionChange` events.
     *
     * Requires `import '@lodev09/react-native-true-sheet/navigation/reanimated'` once, before the
     * navigator renders (e.g. at the top of the root layout). Without it, the screen warns in
     * development and calls `positionChangeHandler` on the JS thread.
     *
     * @default false
     */
    reanimated?: boolean;
    /**
     * A callback that receives position change events.
     * When `reanimated` is enabled, this must be a worklet function.
     *
     * @example
     * ```tsx
     * <Navigator.Screen
     *   name="Sheet"
     *   options={{
     *     reanimated: true,
     *     positionChangeHandler: (payload) => {
     *       'worklet';
     *       animatedValue.value = payload.position;
     *     },
     *   }}
     * />
     * ```
     */
    positionChangeHandler?: PositionChangeHandler;
};
export type TrueSheetNavigatorProps = DefaultNavigatorOptions<ParamListBase, string | undefined, TrueSheetNavigationState<ParamListBase>, TrueSheetNavigationOptions, TrueSheetNavigationEventMap, unknown> & {
    /**
     * The name of the route to use as the base screen.
     * This screen will be rendered as a regular screen, while other screens are presented as sheets.
     * Defaults to the first screen defined in the navigator.
     */
    initialRouteName?: string;
};
export type TrueSheetDescriptor = Descriptor<TrueSheetNavigationOptions, TrueSheetNavigationProp<ParamListBase>, RouteProp<ParamListBase>>;
export type TrueSheetDescriptorMap = {
    [key: string]: TrueSheetDescriptor;
};
//# sourceMappingURL=types.d.ts.map