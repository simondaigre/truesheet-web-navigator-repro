export declare function resolveScrollable(scrollable: unknown): unknown;
//# sourceMappingURL=scrollable.d.ts.map