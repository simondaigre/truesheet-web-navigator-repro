export {};
//# sourceMappingURL=navigationReanimated.d.ts.map