package com.lodev09.truesheet.core

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import com.facebook.react.uimanager.PixelUtil.dpToPx
import com.lodev09.truesheet.utils.isDarkMode

/**
 * Options for customizing the grabber appearance.
 */
data class GrabberOptions(
  val width: Float? = null,
  val height: Float? = null,
  val topMargin: Float? = null,
  val cornerRadius: Float? = null,
  val color: Int? = null,
  val adaptive: Boolean = true
)

/**
 * Options for customizing (e.g. localizing) accessibility strings.
 */
data class AccessibilityOptions(
  val grabberLabel: String? = null,
  val expandedValue: String? = null,
  val collapsedValue: String? = null,
  val detentValue: String? = null,
  val expandActionLabel: String? = null,
  val collapseActionLabel: String? = null,
  val paneTitle: String? = null
)

/**
 * Native grabber (drag handle) view for the bottom sheet.
 * Displays a small pill-shaped indicator at the top of the sheet with a tappable hitbox.
 */
@SuppressLint("ViewConstructor")
class TrueSheetGrabberView(
  context: Context,
  private val options: GrabberOptions? = null,
  private val accessibilityOptions: AccessibilityOptions? = null
) : FrameLayout(context) {

  companion object {
    private const val DEFAULT_WIDTH = 32f // dp
    private const val DEFAULT_HEIGHT = 4f // dp
    private const val DEFAULT_TOP_MARGIN = 16f // dp
    private const val DEFAULT_ALPHA = 0.4f
    private const val HITBOX_PADDING_HORIZONTAL = 16f // dp
    private const val HITBOX_PADDING_VERTICAL = 16f // dp
    private val DEFAULT_COLOR = Color.argb((DEFAULT_ALPHA * 255).toInt(), 73, 69, 79) // #49454F @ 40%
  }

  private val grabberWidth: Float
    get() = options?.width ?: DEFAULT_WIDTH

  private val grabberHeight: Float
    get() = options?.height ?: DEFAULT_HEIGHT

  private val grabberTopMargin: Float
    get() = options?.topMargin ?: DEFAULT_TOP_MARGIN

  private val grabberCornerRadius: Float
    get() = options?.cornerRadius ?: (grabberHeight / 2)

  private val isAdaptive: Boolean
    get() = options?.adaptive ?: true

  private val grabberColor: Int
    get() = if (isAdaptive) getAdaptiveColor(options?.color) else options?.color ?: DEFAULT_COLOR

  var onAccessibilityIncrement: (() -> Unit)? = null
  var onAccessibilityDecrement: (() -> Unit)? = null

  init {
    val hitboxWidth = grabberWidth + (HITBOX_PADDING_HORIZONTAL * 2)
    val hitboxHeight = grabberHeight + (HITBOX_PADDING_VERTICAL * 2)

    layoutParams = LayoutParams(
      hitboxWidth.dpToPx().toInt(),
      hitboxHeight.dpToPx().toInt()
    ).apply {
      gravity = Gravity.CENTER_HORIZONTAL or Gravity.TOP
      topMargin = (grabberTopMargin - HITBOX_PADDING_VERTICAL).dpToPx().toInt()
    }

    // The visible pill centered inside the hitbox
    val pillView = View(context).apply {
      layoutParams = LayoutParams(
        grabberWidth.dpToPx().toInt(),
        grabberHeight.dpToPx().toInt()
      ).apply {
        gravity = Gravity.CENTER
      }
      background = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = grabberCornerRadius.dpToPx()
        setColor(grabberColor)
      }
    }

    addView(pillView)

    isFocusable = true
    contentDescription = accessibilityOptions?.grabberLabel ?: "Drag handle"

    accessibilityDelegate = object : View.AccessibilityDelegate() {
      override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(host, info)
        info.addAction(
          AccessibilityNodeInfo.AccessibilityAction(
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD,
            accessibilityOptions?.expandActionLabel ?: "Expand"
          )
        )
        info.addAction(
          AccessibilityNodeInfo.AccessibilityAction(
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD,
            accessibilityOptions?.collapseActionLabel ?: "Collapse"
          )
        )
        info.className = "android.widget.SeekBar"
      }

      override fun performAccessibilityAction(host: View, action: Int, args: Bundle?): Boolean =
        when (action) {
          AccessibilityNodeInfo.ACTION_SCROLL_FORWARD -> {
            onAccessibilityIncrement?.invoke()
            true
          }

          AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD -> {
            onAccessibilityDecrement?.invoke()
            true
          }

          else -> super.performAccessibilityAction(host, action, args)
        }
    }
  }

  fun updateAccessibilityValue(index: Int, detentCount: Int) {
    val description: CharSequence? = when {
      index < 0 || detentCount <= 0 -> null

      index >= detentCount - 1 -> accessibilityOptions?.expandedValue ?: "Expanded"

      index == 0 -> accessibilityOptions?.collapsedValue ?: "Collapsed"

      else ->
        (accessibilityOptions?.detentValue ?: "Detent {index} of {count}")
          .replace("{index}", "${index + 1}")
          .replace("{count}", "$detentCount")
    }
    ViewCompat.setStateDescription(this, description)
  }

  private fun getAdaptiveColor(baseColor: Int? = null): Int {
    val modeColor = if (context.isDarkMode) Color.WHITE else Color.BLACK

    return if (baseColor != null) {
      // Blend user color with mode color for adaptive effect
      val blendedColor = ColorUtils.blendARGB(baseColor, modeColor, 0.3f)
      ColorUtils.setAlphaComponent(blendedColor, (DEFAULT_ALPHA * 255).toInt())
    } else {
      ColorUtils.setAlphaComponent(modeColor, (DEFAULT_ALPHA * 255).toInt())
    }
  }
}
