package com.lodev09.truesheet

import android.annotation.SuppressLint
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.EditText
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.facebook.react.uimanager.PixelUtil.dpToPx
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.views.view.ReactViewGroup
import com.lodev09.truesheet.core.TrueSheetKeyboardObserver
import com.lodev09.truesheet.core.TrueSheetKeyboardObserverDelegate
import com.lodev09.truesheet.utils.ScreenUtils
import com.lodev09.truesheet.utils.isDescendantOf
import com.lodev09.truesheet.utils.smoothScrollTo

/**
 * What the sheet insets the bottom of the scroll content for — the safe area
 * while it can scroll, and/or an absolute footer floating over it.
 */
enum class TrueSheetContentInsetAdjustment(val safeArea: Boolean, val footer: Boolean) {
  AUTOMATIC(safeArea = true, footer = true),
  SAFE_AREA(safeArea = true, footer = false),
  FOOTER(safeArea = false, footer = true),
  NEVER(safeArea = false, footer = false);

  companion object {
    fun fromString(value: String?): TrueSheetContentInsetAdjustment =
      when (value) {
        "safe-area" -> SAFE_AREA
        "footer" -> FOOTER
        "never" -> NEVER
        else -> AUTOMATIC
      }
  }
}

data class ScrollableOptions(
  val keyboardScrollOffset: Float = 0f,
  val keyboardOffset: Float = 0f,
  val scrollingExpandsSheet: Boolean = true,
  val contentInsetAdjustment: TrueSheetContentInsetAdjustment = TrueSheetContentInsetAdjustment.AUTOMATIC
)

/**
 * Delegate interface for content view size changes
 */
interface TrueSheetContentViewDelegate {
  fun contentViewDidChangeSize(width: Int, height: Int)
  fun contentViewDidScroll()
  fun contentViewScrollViewDidChange()

  /**
   * Keyboard occlusion adjustment below the content — positive for an absolute
   * footer floating over the viewport's bottom edge (extends the caret reveal),
   * negative for a relative footer sitting behind the keyboard shielding that
   * much of its overlap (reduces the keyboard padding).
   */
  val footerKeyboardOcclusion: Int

  /**
   * Layout height of an absolute footer floating over the content, including
   * its absorbed safe-area inset — 0 for a relative footer.
   */
  val absoluteFooterHeight: Int

  // Includes the controller's translation during sheet transitions.
  val absoluteFooterTop: Int

  /**
   * false when an absolute footer stays behind the keyboard instead of rising
   * above it.
   */
  val footerAvoidsKeyboard: Boolean

  /**
   * A relative footer sits below the content and absorbs the bottom safe-area
   * inset — the scrollable doesn't reach the sheet's bottom edge, so no
   * content inset is applied (mirrors iOS, where UIKit resolves this
   * geometrically via the scroll view's safe area).
   */
  val hasRelativeFooter: Boolean
}

/**
 * Content view that holds the main sheet content
 * This is the first child of TrueSheetContainerView
 */
@SuppressLint("ViewConstructor")
class TrueSheetContentView(private val reactContext: ThemedReactContext) : ReactViewGroup(reactContext) {
  var delegate: TrueSheetContentViewDelegate? = null

  private var detectedScrollView: ViewGroup? = null

  /**
   * Content height measured unconstrained by the shadow node — the height the
   * content wants regardless of container bounds (see
   * TrueSheetContentViewShadowNode). Falls back to the view height before the
   * first state update.
   */
  val naturalHeight: Int
    get() = if (lastNaturalHeight > 0) lastNaturalHeight else height

  private var lastNaturalHeight = 0

  fun updateNaturalHeight(heightDp: Double) {
    val heightPx = heightDp.toFloat().dpToPx().toInt()
    if (heightPx == lastNaturalHeight) return
    lastNaturalHeight = heightPx
    delegate?.contentViewDidChangeSize(width, heightPx)
  }

  private var keyboardScrollOffset: Float = 0f

  /**
   * Adjustment added to the keyboard bottom inset applied to the detected
   * scrollable — negative values reduce the inset (e.g. to cancel out safe-area
   * padding already baked into the content's paddingBottom).
   */
  private var keyboardOffset: Float = 0f

  /**
   * How much of keyboardOffset actually landed in the applied inset — the
   * caret reveal compensates by this so it still targets the real keyboard edge.
   */
  private var appliedKeyboardOffset = 0

  private var keyboardObserver: TrueSheetKeyboardObserver? = null

  private var watchedEditText: EditText? = null
  private var caretTextWatcher: TextWatcher? = null

  var scrollableOptions: ScrollableOptions? = null
    set(value) {
      field = value
      keyboardScrollOffset = value?.keyboardScrollOffset?.dpToPx() ?: 0f
      keyboardOffset = value?.keyboardOffset?.dpToPx() ?: 0f
      updateContentInset()
    }

  /**
   * Bottom safe-area inset applied to the scrollable's content padding while
   * the content can scroll — Android counterpart of iOS's
   * `contentInsetAdjustmentBehavior="automatic"`. Already zero when the
   * sheet's `insetAdjustment` is `'never'`.
   */
  var bottomInset: Int = 0
    set(value) {
      if (field == value) return
      field = value
      updateContentInset()
    }

  private var baseBottomInset = 0
  private var keyboardBottomInset = 0

  /**
   * Height of the absolute footer the scroll content is padded by (see
   * ScrollableOptions.contentInsetAdjustment), applied on top of the
   * safe-area or keyboard inset.
   */
  private var footerBottomInset = 0

  private val scrollableLayoutListener = ViewTreeObserver.OnGlobalLayoutListener {
    updateContentInset()
  }

  private val scrollContentLayoutListener = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
    updateContentInset()
  }

  override fun onAttachedToWindow() {
    super.onAttachedToWindow()
    viewTreeObserver.addOnGlobalLayoutListener(scrollableLayoutListener)
  }

  override fun onDetachedFromWindow() {
    viewTreeObserver.removeOnGlobalLayoutListener(scrollableLayoutListener)
    super.onDetachedFromWindow()
  }

  /**
   * React tag of the user-provided scrollable (see the `scrollableRef` prop).
   * Setting a new handle clears the currently resolved ScrollView.
   */
  var scrollableHandle: Int = -1
    set(value) {
      if (field == value) return
      field = value
      clearScrollable()
    }

  override fun addView(child: View?, index: Int) {
    super.addView(child, index)
    checkScrollViewChanged()
  }

  override fun removeViewAt(index: Int) {
    super.removeViewAt(index)
    checkScrollViewChanged()
  }

  private fun checkScrollViewChanged() {
    if (detectedScrollView == null || detectedScrollView?.isDescendantOf(this) == false) {
      delegate?.contentViewScrollViewDidChange()
    }
  }

  fun setupScrollable() {
    // Check if the detected scroll view is still valid (still in view hierarchy)
    if (detectedScrollView != null && detectedScrollView?.isDescendantOf(this) == false) {
      clearScrollable()
    }

    if (detectedScrollView != null) {
      return
    }

    val scrollView = findScrollView() ?: return

    detectedScrollView = scrollView

    scrollView.isNestedScrollingEnabled = true
    (scrollView.parent as? SwipeRefreshLayout)?.isNestedScrollingEnabled = false

    scrollView.setOnScrollChangeListener { _, _, scrollY, _, oldScrollY ->
      if (scrollY != oldScrollY) {
        delegate?.contentViewDidScroll()
      }
    }

    // Restore the inset before ReactScrollView's listener clamps the offset.
    scrollView.getChildAt(0)?.let { child ->
      if (scrollView is View.OnLayoutChangeListener) child.removeOnLayoutChangeListener(scrollView)
      child.addOnLayoutChangeListener(scrollContentLayoutListener)
      if (scrollView is View.OnLayoutChangeListener) child.addOnLayoutChangeListener(scrollView)
    }

    updateContentInset()
  }

  /**
   * Re-applies the base content inset — the bottom safe-area inset while the
   * content can scroll, no relative footer absorbs it, and
   * `contentInsetAdjustment` includes the safe area.
   */
  fun updateContentInset() {
    val scrollView = detectedScrollView ?: return

    val enabled = scrollableOptions?.contentInsetAdjustment?.safeArea ?: true
    baseBottomInset = if (enabled && delegate?.hasRelativeFooter != true && canScrollContent(scrollView)) {
      bottomInset
    } else {
      0
    }

    updateScrollViewInsetForKeyboard(keyboardObserver?.currentHeight ?: 0)
  }

  // Fabric's measured height excludes the native inset, avoiding feedback.
  private fun canScrollContent(scrollView: ViewGroup): Boolean {
    val child = scrollView.getChildAt(0) ?: return false
    return child.measuredHeight > scrollView.height - scrollView.paddingTop - scrollView.paddingBottom
  }

  // The keyboard covers the safe-area region, so the larger inset wins over a sum
  private fun applyBottomInset() {
    val safeAreaInset = maxOf(baseBottomInset, keyboardBottomInset)
    footerBottomInset = footerInsetAbove(safeAreaInset)
    setScrollContentInset(safeAreaInset + footerBottomInset)
  }

  // A pinned footer uses its positioned top so overlap follows the sheet's
  // animation, even before the container reaches its final height. A rising
  // footer uses its layout top because the keyboard inset carries its rise.
  // The safe-area inset baked into the footer is already
  // covered by the safe-area or keyboard inset when one applies — only the
  // footer's occlusion above it stacks on top. A pinned footer adds only the
  // overlap not already covered by the safe-area or keyboard inset.
  private fun footerInsetAbove(safeAreaInset: Int): Int {
    if (scrollableOptions?.contentInsetAdjustment?.footer == false) return 0
    val scrollView = detectedScrollView ?: return 0
    val container = parent as? View ?: return 0
    val footerHeight = delegate?.absoluteFooterHeight ?: 0
    if (footerHeight <= 0) return 0

    var scrollBottom = scrollView.bottom
    var view: View = scrollView.parent as? View ?: return 0
    while (view !== container) {
      scrollBottom += view.top
      view = view.parent as? View ?: return 0
    }

    val footerTop = if (delegate?.footerAvoidsKeyboard == false) {
      delegate?.absoluteFooterTop ?: return 0
    } else {
      container.height - footerHeight
    }
    var inset = scrollBottom - footerTop
    if (delegate?.footerAvoidsKeyboard == false) {
      inset -= safeAreaInset
    } else if (safeAreaInset > 0) {
      inset -= footerHeight - maxOf(0, delegate?.footerKeyboardOcclusion ?: 0)
    }
    return maxOf(0, inset)
  }

  private fun setScrollContentInset(inset: Int) {
    val scrollView = detectedScrollView ?: return
    val child = scrollView.getChildAt(0) ?: return
    scrollView.clipToPadding = false
    // ScrollView's canScrollVertically ignores bottom padding. Extend the
    // content bounds instead, keeping Fabric's measured height as the baseline.
    child.bottom = child.top + child.measuredHeight + inset
  }

  fun clearScrollable() {
    detectedScrollView?.setOnScrollChangeListener(null as View.OnScrollChangeListener?)
    detectedScrollView?.getChildAt(0)?.removeOnLayoutChangeListener(scrollContentLayoutListener)
    detectedScrollView?.isNestedScrollingEnabled = false
    (detectedScrollView?.parent as? SwipeRefreshLayout)?.isNestedScrollingEnabled = true
    setScrollContentInset(0)
    detectedScrollView = null
    baseBottomInset = 0
    keyboardBottomInset = 0
    footerBottomInset = 0
    appliedKeyboardOffset = 0
  }

  /**
   * Resolves the user-provided `scrollableHandle` within the content subtree —
   * React tags are view ids on Android.
   */
  fun findScrollView(): ViewGroup? {
    if (detectedScrollView != null) return detectedScrollView
    if (scrollableHandle <= 0) return null
    return findViewById<View>(scrollableHandle) as? ViewGroup
  }

  // ==================== Keyboard Handling ====================

  fun setupKeyboardHandler() {
    if (keyboardObserver != null) return

    keyboardObserver = TrueSheetKeyboardObserver(this, reactContext).apply {
      delegate = object : TrueSheetKeyboardObserverDelegate {
        // Drive the inset per keyboard animation frame so the content tracks
        // the keyboard edge instead of jumping to the final inset up front.
        // On hide, the shrinking inset gradually clamps the scroll position
        // back in sync with the keyboard.
        override fun keyboardDidChangeHeight(height: Int) {
          updateScrollViewInsetForKeyboard(height)

          // Follow the caret frame-by-frame — only API 30+ delivers
          // incremental heights; legacy fires once after the keyboard is
          // already up, where keyboardDidShow's smooth reveal takes over
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !isHiding) {
            scrollToFocusedInput(smooth = false)
          }
        }

        override fun keyboardDidShow(height: Int) {
          attachCaretListener()
          scrollToFocusedInput()
        }

        override fun keyboardWillHide() {
          detachCaretListener()
        }

        override fun focusDidChange(newFocus: View) {
          attachCaretListener()
          scrollToFocusedInput()
        }
      }
      start()
    }
  }

  fun cleanupKeyboardHandler() {
    detachCaretListener()
    keyboardObserver?.stop()
    keyboardObserver = null
  }

  private fun attachCaretListener() {
    val focused = findFocus() as? EditText
    if (focused === watchedEditText) return

    detachCaretListener()
    if (focused == null) return

    val watcher = object : TextWatcher {
      override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
      override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
      override fun afterTextChanged(s: Editable?) {
        focused.post { scrollToFocusedInput() }
      }
    }

    focused.addTextChangedListener(watcher)
    watchedEditText = focused
    caretTextWatcher = watcher
  }

  private fun detachCaretListener() {
    caretTextWatcher?.let { watchedEditText?.removeTextChangedListener(it) }
    caretTextWatcher = null
    watchedEditText = null
  }

  private fun updateScrollViewInsetForKeyboard(keyboardHeight: Int) {
    val scrollView = detectedScrollView ?: return

    // Short or nested scroll views can end above the sheet's bottom edge.
    // Their position also accounts for space occupied by a relative footer.
    keyboardBottomInset = if (keyboardHeight > 0) {
      val location = IntArray(2)
      scrollView.getLocationInWindow(location)
      val keyboardTop = ScreenUtils.getRealScreenHeight(reactContext) - keyboardHeight
      val baseInset = maxOf(0, location[1] + scrollView.height - keyboardTop)
      val adjustedInset = maxOf(0, baseInset + keyboardOffset.toInt())
      appliedKeyboardOffset = adjustedInset - baseInset
      if (delegate?.footerAvoidsKeyboard == false) {
        appliedKeyboardOffset += footerInsetAbove(maxOf(baseBottomInset, adjustedInset)) -
          footerInsetAbove(maxOf(baseBottomInset, baseInset))
      }
      adjustedInset
    } else {
      appliedKeyboardOffset = 0
      0
    }
    applyBottomInset()
    clampScrollPosition()
  }

  // Content bounds changes don't re-clamp the scroll position until the next layout
  // pass — clamp synchronously so the content follows the shrinking inset on
  // every keyboard frame instead of snapping afterwards
  private fun clampScrollPosition() {
    val scrollView = detectedScrollView ?: return
    val child = scrollView.getChildAt(0) ?: return
    val maxScrollY = maxOf(0, child.height - (scrollView.height - scrollView.paddingTop - scrollView.paddingBottom))
    if (scrollView.scrollY > maxScrollY) {
      scrollView.scrollTo(scrollView.scrollX, maxScrollY)
    }
  }

  private fun scrollToFocusedInput(smooth: Boolean = true) {
    val scrollView = detectedScrollView ?: findScrollView() ?: return
    val focusedView = findFocus() ?: return
    if (!focusedView.isDescendantOf(scrollView)) return

    val focusedLocation = IntArray(2)
    val scrollViewLocation = IntArray(2)
    focusedView.getLocationOnScreen(focusedLocation)
    scrollView.getLocationOnScreen(scrollViewLocation)

    val viewTop = focusedLocation[1] - scrollViewLocation[1] + scrollView.scrollY

    // Resolve the caret's line within the focused input so we follow the cursor
    // rather than the input's full bounds (which over-scrolls tall inputs).
    val editText = focusedView as? EditText
    val layout = editText?.layout

    val caretTop: Int
    val caretBottom: Int
    if (editText != null && layout != null) {
      val line = layout.getLineForOffset(editText.selectionEnd.coerceAtLeast(0))
      val textTop = viewTop + editText.totalPaddingTop - editText.scrollY
      caretTop = textTop + layout.getLineTop(line)
      caretBottom = textTop + layout.getLineBottom(line)
    } else {
      caretTop = viewTop
      caretBottom = viewTop + focusedView.height
    }

    // An absolute footer floats over the viewport's bottom edge — extend the
    // caret target so it clears the footer, not just the keyboard. Not needed
    // while the footer inset is applied (the visible range already ends above
    // it) or when the footer stays behind the keyboard.
    val footerOcclusion = if (footerBottomInset > 0 || delegate?.footerAvoidsKeyboard == false) {
      0
    } else {
      maxOf(0, delegate?.footerKeyboardOcclusion ?: 0)
    }

    val offset = keyboardScrollOffset.toInt()
    val appliedInset = maxOf(baseBottomInset, keyboardBottomInset) + footerBottomInset
    val visibleHeight = scrollView.height - scrollView.paddingBottom - appliedInset + appliedKeyboardOffset
    val visibleTop = scrollView.scrollY
    val visibleBottom = scrollView.scrollY + visibleHeight

    val targetY = when {
      caretBottom + offset + footerOcclusion > visibleBottom ->
        caretBottom + offset + footerOcclusion - visibleHeight

      caretTop - offset < visibleTop ->
        (caretTop - offset).coerceAtLeast(0)

      else -> return
    }

    if (smooth) {
      scrollView.smoothScrollTo(0, targetY)
    } else {
      scrollView.scrollTo(0, targetY)
    }
  }

  companion object {
    const val TAG_NAME = "TrueSheet"
  }
}
