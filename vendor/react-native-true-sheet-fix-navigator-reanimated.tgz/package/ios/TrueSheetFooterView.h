//
//  Created by Jovanni Lo (@lodev09)
//  Copyright (c) 2024-present. All rights reserved.
//
//  This source code is licensed under the MIT license found in the
//  LICENSE file in the root directory of this source tree.
//

#ifdef RCT_NEW_ARCH_ENABLED

#import <React/RCTSurfaceTouchHandler.h>
#import <React/RCTViewComponentView.h>
#import <UIKit/UIKit.h>
#import "core/TrueSheetKeyboardObserver.h"

@class TrueSheetViewController;

NS_ASSUME_NONNULL_BEGIN

@protocol TrueSheetFooterViewDelegate <NSObject>
@optional
- (void)footerViewDidChangeSize:(CGSize)size;
@end

@interface TrueSheetFooterView : RCTViewComponentView <TrueSheetKeyboardObserverDelegate>

@property (nonatomic, weak, nullable) TrueSheetKeyboardObserver *keyboardObserver;
@property (nonatomic, weak, nullable) id<TrueSheetFooterViewDelegate> delegate;

/**
 * Bottom inset currently baked into the footer's layout height — pairs with
 * the measured frame so detent math can subtract exactly what's baked in.
 */
@property (nonatomic, readonly) CGFloat appliedBottomInset;

/**
 * Re-applies the footer's keyboard slide using the current keyboard height.
 * No-op when the keyboard is hidden. Used to reflect live `keyboardOffset` changes.
 */
- (void)applyKeyboardOffset;

/**
 * Bottom safe-area inset the footer absorbs as padding (via the shadow node)
 * so its content clears the home indicator and the background fills the inset.
 */
- (void)setBottomInset:(CGFloat)bottomInset;

/**
 * Height the footer occupies above the keyboard — its layout height minus
 * the safe-area inset it drops while the keyboard is open.
 */
- (CGFloat)keyboardOcclusionHeight;

@end

NS_ASSUME_NONNULL_END

#endif
