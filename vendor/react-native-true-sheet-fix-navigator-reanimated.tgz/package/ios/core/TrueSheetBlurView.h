//
//  Created by Jovanni Lo (@lodev09)
//  Copyright (c) 2024-present. All rights reserved.
//
//  This source code is licensed under the MIT license found in the
//  LICENSE file in the root directory of this source tree.
//

#import <UIKit/UIKit.h>
#import <react/renderer/components/TrueSheetSpec/Props.h>

NS_ASSUME_NONNULL_BEGIN

@interface TrueSheetBlurView : UIVisualEffectView

@property (nonatomic, assign) facebook::react::TrueSheetViewBackgroundBlur backgroundBlur;

/// Adds the blur view to a parent view with proper constraints
- (void)addToView:(UIView *)parentView;

- (void)applyBlurEffect;

@end

NS_ASSUME_NONNULL_END
