//
//  Created by Jovanni Lo (@lodev09)
//  Copyright (c) 2024-present. All rights reserved.
//
//  This source code is licensed under the MIT license found in the
//  LICENSE file in the root directory of this source tree.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Protocol that provides dynamic measurements for detent calculations.
 Implemented by TrueSheetViewController to supply real-time values.
 */
@protocol TrueSheetDetentCalculatorDelegate <NSObject>

@property (nonatomic, readonly) CGFloat screenHeight;
@property (nonatomic, readonly) CGFloat currentPosition;
@property (nonatomic, strong, readonly) NSArray<NSNumber *> *detents;
@property (nonatomic, strong, readonly, nullable) NSNumber *contentHeight;
@property (nonatomic, strong, readonly, nullable) NSNumber *headerHeight;
@property (nonatomic, readonly) BOOL absoluteHeader;
@property (nonatomic, strong, readonly, nullable) NSNumber *footerHeight;
@property (nonatomic, readonly) BOOL absoluteFooter;
@property (nonatomic, readonly) BOOL footerInsetAdjustment;
@property (nonatomic, readonly) BOOL footerAvoidsKeyboard;
@property (nonatomic, readonly) CGFloat appliedFooterBottomInset;
@property (nonatomic, strong, readonly, nullable) NSNumber *peekContentHeight;

@end

/**
 Encapsulates all detent-related calculations for the sheet.
 */
@interface TrueSheetDetentCalculator : NSObject

@property (nonatomic, weak, nullable) id<TrueSheetDetentCalculatorDelegate> delegate;
@property (nonatomic, assign) CGFloat maxDetentHeight;
@property (nonatomic, strong, nullable) NSMutableArray<NSNumber *> *resolvedDetentHeights;

/**
 Returns the detent value (0-1 fraction) for a given index.
 For auto (-1) detents, calculates based on content + header height.
 For peek (-2) detents, calculates based on header + footer height.
 */
- (CGFloat)detentValueForIndex:(NSInteger)index;
- (NSInteger)backgroundIndexForPosition:(CGFloat)position displayedIndex:(NSInteger)displayedIndex;

/**
 Returns the height for auto (-1) detents: content + header + footer height.
 An absolute (floating) header or footer contributes no height.
 A pinned footer contributes only its overlap above the keyboard. UIKit adds
 the keyboard expansion separately. Pass 0 for the keyboard-free height.
 */
- (CGFloat)autoHeightForKeyboardHeight:(CGFloat)keyboardHeight;

/**
 Returns the height for peek (-2) detents: header + footer + peek content height.
 A relative footer is pushed off-screen at peek, so it contributes no height.
 Falls back to 150 when none is present.
 */
- (CGFloat)peekHeight;

/**
 Learns the offset between resolver height and actual presented height for a detent.
 Called when the sheet settles at a detent.
 */
- (void)learnOffsetForDetentIndex:(NSInteger)index;

/**
 Returns the expected sheet height for a detent index: the UIKit-resolved
 height plus the learned offset.
 */
- (CGFloat)resolvedHeightForIndex:(NSInteger)index;

/**
 Returns the offset learned for this detent itself, or 0 when none is learned.
 */
- (CGFloat)learnedOffsetForIndex:(NSInteger)index;

/**
 Sets the offset this detent is expected to rest with, unless its learned
 offset is already within a point of it.
 */
- (void)assumeOffset:(CGFloat)offset forIndex:(NSInteger)index;

/**
 Finds the segment between detents for a given position.
 Returns YES if position is between two detents, NO if at edges.
 outIndex: The lower detent index of the segment (-1 if above first detent)
 outProgress: Progress within the segment (0-1)
 */
- (BOOL)findSegmentForPosition:(CGFloat)position outIndex:(NSInteger *)outIndex outProgress:(CGFloat *)outProgress;

/**
 Returns a continuous index value representing position between detents.
 Examples: 0.5 means halfway between detent 0 and 1
           -0.3 means 30% toward closed from detent 0
 */
- (CGFloat)interpolatedIndexForPosition:(CGFloat)position;

/**
 Returns the interpolated detent value for a given position.
 Useful for getting a smooth detent value during drag.
 */
- (CGFloat)interpolatedDetentForPosition:(CGFloat)position;

/**
 Clears all resolved heights and learned offsets.
 Called when detents configuration changes.
 */
- (void)clearResolvedHeights;

/**
 Sets the count of detents (initializes storage for resolved positions).
 */
- (void)setDetentCount:(NSInteger)count;

@end

NS_ASSUME_NONNULL_END
