//
//  Created by Jovanni Lo (@lodev09)
//  Copyright (c) 2024-present. All rights reserved.
//
//  This source code is licensed under the MIT license found in the
//  LICENSE file in the root directory of this source tree.
//

#import <UIKit/UIKit.h>
#import <react/renderer/components/TrueSheetSpec/Props.h>
#import "core/TrueSheetDetentCalculator.h"
#import "core/TrueSheetGrabberView.h"

#if __has_include(<RNScreens/RNSDismissibleModalProtocol.h>)
#import <RNScreens/RNSDismissibleModalProtocol.h>
#define RNS_DISMISSIBLE_MODAL_PROTOCOL_AVAILABLE 1
#else
#define RNS_DISMISSIBLE_MODAL_PROTOCOL_AVAILABLE 0
#endif

NS_ASSUME_NONNULL_BEGIN

@protocol TrueSheetViewControllerDelegate <NSObject>

- (void)viewControllerWillPresentAtIndex:(NSInteger)index position:(CGFloat)position detent:(CGFloat)detent;
- (void)viewControllerDidPresentAtIndex:(NSInteger)index position:(CGFloat)position detent:(CGFloat)detent;
- (void)viewControllerWillDismiss;
- (void)viewControllerDidDismiss;
- (void)viewControllerDidAttemptDismiss;
- (void)viewControllerDidChangeDetent:(NSInteger)index position:(CGFloat)position detent:(CGFloat)detent;
- (void)viewControllerDidDrag:(UIGestureRecognizerState)state
                        index:(NSInteger)index
                     position:(CGFloat)position
                       detent:(CGFloat)detent;
- (void)viewControllerDidChangePosition:(CGFloat)index
                               position:(CGFloat)position
                                 detent:(CGFloat)detent
                               realtime:(BOOL)realtime;
- (void)viewControllerDidChangeSize:(CGSize)size;
- (void)viewControllerSafeAreaInsetsDidChange;
- (void)viewControllerWillFocus;
- (void)viewControllerDidFocus;
- (void)viewControllerWillBlur;
- (void)viewControllerDidBlur;

@end

@interface TrueSheetViewController : UIViewController <UISheetPresentationControllerDelegate,
                                       TrueSheetDetentCalculatorDelegate
#if RNS_DISMISSIBLE_MODAL_PROTOCOL_AVAILABLE
                                       ,
                                       RNSDismissibleModalProtocol
#endif
                                       >

@property (nonatomic, weak, nullable) id<TrueSheetViewControllerDelegate> delegate;
@property (nonatomic, strong) NSArray<NSNumber *> *detents;
@property (nonatomic, copy) NSArray<NSDictionary *> *detentBackgrounds;
@property (nonatomic, strong, nullable) NSNumber *maxContentHeight;
@property (nonatomic, strong, nullable) NSNumber *maxContentWidth;
@property (nonatomic, strong, nullable) NSNumber *contentHeight;
@property (nonatomic, strong, nullable) NSNumber *headerHeight;
@property (nonatomic, assign) BOOL absoluteHeader;
@property (nonatomic, strong, nullable) NSNumber *footerHeight;
@property (nonatomic, assign) BOOL absoluteFooter;

/**
 * YES while the plugged scrollable is padded by the absolute footer's height
 * (see ScrollableOptions.contentInsetAdjustment) — the footer then counts
 * toward the auto detent like a relative one, so the content ends above it.
 */
@property (nonatomic, assign) BOOL footerInsetAdjustment;
@property (nonatomic, strong, nullable) NSNumber *peekContentHeight;
@property (nonatomic, strong, nullable) UIColor *backgroundColor;
@property (nonatomic, strong, nullable) NSNumber *cornerRadius;
@property (nonatomic, assign) BOOL grabber;
@property (nonatomic, strong, nullable) GrabberOptions *grabberOptions;
@property (nonatomic, assign) facebook::react::TrueSheetViewAccessibilityOptionsStruct accessibilityOptions;
@property (nonatomic, assign) BOOL draggable;
@property (nonatomic, assign) BOOL dimmed;
@property (nonatomic, strong, nullable) UIColor *dimColor;
@property (nonatomic, strong, nullable) NSNumber *dimOpacity;
@property (nonatomic, strong, nullable) NSNumber *dimmedDetentIndex;
@property (nonatomic, assign) facebook::react::TrueSheetViewBackgroundBlur backgroundBlur;
@property (nonatomic, assign) facebook::react::TrueSheetViewPresentation presentation;
@property (nonatomic, assign) facebook::react::TrueSheetViewPlacement placement;
@property (nonatomic, assign) facebook::react::TrueSheetViewFoldOptionsStruct foldOptions;
@property (nonatomic, assign) facebook::react::TrueSheetViewInsetAdjustment insetAdjustment;
@property (nonatomic, assign) BOOL scrollingExpandsSheet;
@property (nonatomic, assign) CGFloat footerKeyboardOffset;

/**
 * NO keeps an absolute footer pinned to the sheet's bottom edge behind the
 * keyboard instead of rising above it.
 */
@property (nonatomic, assign) BOOL footerAvoidsKeyboard;
@property (nonatomic, assign) BOOL dismissible;
@property (nonatomic, assign) BOOL isPresented;
@property (nonatomic, assign) NSInteger activeDetentIndex;

/**
 * YES while the keyboard has the sheet grown beyond its detent height.
 * Offset learning is skipped in this state — the measured frame would bake
 * ~keyboardHeight into the learned offset.
 */
@property (nonatomic, assign) BOOL keyboardSheetGrown;

/**
 * Target keyboard height, set as soon as the keyboard frame change is
 * announced — ahead of the grow/shrink animation, unlike keyboardSheetGrown.
 */
@property (nonatomic, assign) CGFloat keyboardHeight;

/**
 * How far UIKit grows the sheet for the iPadOS minimized keyboard, which it
 * treats as docked. Taken off every detent so the sheet stays put.
 */
@property (nonatomic, assign) CGFloat minimizedKeyboardOverlap;

@property (nonatomic, readonly) BOOL isTopmostPresentedController;
@property (nonatomic, readonly) BOOL isStackedBehindChild;
@property (nonatomic, weak, nullable) UIView *accessibilityContentView;

@property (nonatomic, readonly) CGFloat screenHeight;

/**
 * Bottom safe-area inset the footer absorbs as padding — the footer
 * owns the sheet's bottom edge, so its background fills the inset.
 */
@property (nonatomic, readonly) CGFloat footerBottomInset;

/**
 * The inset currently baked into the footer's measured height, reported
 * alongside its layout (see TrueSheetFooterView.appliedBottomInset). Detent
 * resolution subtracts this exact value so the baked inset is never
 * double-counted.
 */
@property (nonatomic, assign) CGFloat appliedFooterBottomInset;

- (void)setupAccessibilityContainer;
- (void)refreshAccessibilityContainer;
- (void)refreshAccessibilityContainerIfFooterChanged;

- (void)applyActiveDetent;
- (void)setupActiveDetentWithIndex:(NSInteger)index;
- (void)resizeToDetentIndex:(NSInteger)index;
- (void)setupSheetSizing;
- (void)setupSheetProps;
- (void)setupSheetDetents;
- (void)setupSheetDetentsForSizeChange;
- (void)setupSheetDetentsForDetentsChange;
- (void)invalidateDetents;
- (void)setupDraggable;
- (void)setupAnchorViewInView:(UIView *)parentView;

- (void)beginInteractiveDismiss;
- (void)updateInteractiveDismiss:(CGFloat)progress;
- (void)cancelInteractiveDismissWithDuration:(NSTimeInterval)duration;
- (void)finishInteractiveDismissWithDuration:(NSTimeInterval)duration completion:(void (^)(void))completion;

@end

NS_ASSUME_NONNULL_END
